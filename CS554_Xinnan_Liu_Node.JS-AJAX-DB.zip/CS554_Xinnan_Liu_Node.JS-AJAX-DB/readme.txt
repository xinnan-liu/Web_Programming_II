For the mysql connection, there is no problem for the program.

However, when I combine the node.js with html file, and using ajax under html, there pop 

out a significant problem.

Console always says that Cannot enqueue Handshake after invoking quit.

I guess probably due to my setting fault between node.js and index.html file that ajax 

cannot receive the data from node.js.

Hope you can do some comment and help for me.